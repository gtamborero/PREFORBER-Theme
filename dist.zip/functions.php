<?php
/**
 * Sage includes
 *
 * The $sage_includes array determines the code library included in your theme.
 * Add or remove files to the array as needed. Supports child theme overrides.
 *
 * Please note that missing files will produce a fatal error.
 *
 * @link https://github.com/roots/sage/pull/1042
 */
$sage_includes = [
  'lib/assets.php',    // Scripts and stylesheets
  'lib/extras.php',    // Custom functions
  'lib/setup.php',     // Theme setup
  'lib/titles.php',    // Page titles
  'lib/wrapper.php',   // Theme wrapper class
  'lib/customizer.php', // Theme customizer
  'lib/nav-walker.php' // Theme customizer
];

foreach ($sage_includes as $file) {
  if (!$filepath = locate_template($file)) {
    trigger_error(sprintf(__('Error locating %s for inclusion', 'sage'), $file), E_USER_ERROR);
  }

  require_once $filepath;
}
unset($file, $filepath);

// EXCERPT LENGHT
function custom_excerpt_length( $length ) {
	return 20;
}
add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );

// DELETE COMMENTS BUTTON ON ADMIN
add_action( 'admin_init', 'my_remove_admin_menus' );
function my_remove_admin_menus() {
    remove_menu_page( 'edit-comments.php' );
}

// REMOVE POST FORMAT SUPPORT
add_action('after_setup_theme', 'remove_post_formats', 11);
function remove_post_formats() {
    remove_theme_support('post-formats');
}

function iproRenderTipos($post){
?>
		<div class="col-md-3 col-xs-6 iproRenderTipo">
		<a class="fullLink" href="<?php echo get_post_meta($post->ID, "wpcf-url-destino", true); ?>"></a>
			<div class="medpadbottom productTitle"><?php echo get_the_title(); ?></div>
			<div class="iproText"><div class="color2line"></div><?php echo get_the_excerpt(); ?></div>
			<div class="button">+ info</div>
		</div>
<?php
}

function iproRenderProductos($post){
?>
		<div class="col-md-3 col-xs-6">
			<div class="iproRenderProductos">
			<a class="fullLink" href="<?php echo get_the_permalink(); ?>"></a>
				<?php if(has_post_thumbnail()): ?><img src="<?= the_post_thumbnail_url(); ?>"><?php endif; ?>
				<div class="iproProductoInner">
					<div class="medpadbottom productTitle"><?php echo get_the_title(); ?></div>
					<div class="iproText"><?php echo get_the_excerpt(); ?></div>
					<div class="pull-left iproPrice"><?php echo '<strike>' . get_post_meta( $post->ID, '_regular_price', true) . '€</strike> ' . get_post_meta( $post->ID, '_sale_price', true) . '€'; ?> + IVA</div> <div class="button circle pull-right">+</div>
					
				</div>
			</div>
		</div>
<?php
}

function iproRenderNoticias($post){
?>
		<div class="col-md-6 col-xs-12 textleft">
		
			<div style="float:left; color:#777; padding-bottom:8px;"><?php  echo get_the_term_list( $post->ID, 'category', '', '&nbsp; '); ?></div>
			<div style="float:right; color:#777;  padding-bottom:8px;">25 05</div>
			
			<div class="iproRenderNoticias">
				<?php if(has_post_thumbnail()): ?><img src="<?= the_post_thumbnail_url(); ?>"><?php endif; ?>
				<div class="iproProductoInner">
					<div class="medpadbottom maxpadtop productTitle"><?php echo get_the_title(); ?></div>
					<div class="text"><?php echo get_the_excerpt(); ?></div>
					<div class="readmore">LEER MÁS &nbsp; ></div>
					<a class="fullLink" href="<?php echo get_the_permalink(); ?>"></a>
				</div>
			</div>
		</div>
<?php
}
