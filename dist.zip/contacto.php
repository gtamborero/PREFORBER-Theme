<?php
/**
 * Template Name: CONTACTO
 */
?>

<div class="medpad minpadtop minpadbottom col-md-12">
	<div class="entry-content textjustify">
	  <?php the_content(); ?>
	</div>
</div>

