<?php
/**
 * Template Name: INICIO
 */
?>

</div>


<!-- TIPOS DE CLIENTE -->
<div class="text-center bg1container">
	<?php
	
		wp_reset_query();
		$posts = get_posts(array(
			'showposts' => 4, 
			'post_type' => 'producto-home',
			'cache_results' => false, // para mejorar rendimiento en dev o prod
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
			'no_found_rows' => true, // para mejorar rendimiento si no existe paginacion
		));
		
		
		//echo '<pre>' . var_export($posts, true) . '</pre>';
		foreach ( $posts as $post ) {   
			iproRenderTipos ($post);
		}
	?>
</div>
<!-- FIN TIPOS CLIENTE -->

<!-- PRODUCTOS -->
<div class="bg2container text-center">
<div class="headTitle">PRODUCTOS</div>
	<?php
	
		wp_reset_query();
		$posts = get_posts(array(
			'showposts' => 4, 
			'post_type' => 'product',
			'cache_results' => false, // para mejorar rendimiento en dev o prod
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
			'no_found_rows' => true, // para mejorar rendimiento si no existe paginacion
		));
		
		
		//echo '<pre>' . var_export($posts, true) . '</pre>';
		foreach ( $posts as $post ) {   
			iproRenderProductos ($post);
		}
	?>
</div>
<!-- FIN PRODUCTOS -->

<!-- DESCARGAR INFORMES -->
<div class="iproCall text-center">
	<a href=""><div>
		DESCÁRGATE NUESTROS ÚLTIMOS INFORMES <img id="hide" src="<?= get_template_directory_uri(); 
?>/dist/images/flecha-derecha-blanca.png">
	</div></a>
</div>
<!-- FIN DESCARGAR INFORMES -->

<!-- NOTICIAS -->
<div class="text-center bg1container">
<div class="headTitle textleft grey">ÚLTIMAS NOTICIAS</div>
	<?php
	
		wp_reset_query();
		$posts = get_posts(array(
			'showposts' => 2, 
			'post_type' => 'post',
			'cache_results' => false, // para mejorar rendimiento en dev o prod
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
			'no_found_rows' => true, // para mejorar rendimiento si no existe paginacion
		));
		
		
		//echo '<pre>' . var_export($posts, true) . '</pre>';
		foreach ( $posts as $post ) {   
			iproRenderNoticias ($post);
		}
	?>
</div>
<!-- FIN NOTICIAS -->

<!-- DESCARGAR INFORMES -->
<div class="iproNewsletter">
	<div>SUSCRÍBETE A NUESTRA NEWSLETTER <img id="hide" src="<?= get_template_directory_uri(); ?>/dist/images/flecha-derecha-blanca.png"></div>
</div>
<!-- FIN DESCARGAR INFORMES -->

<!-- MAS INFO / CONTACT FORM -->
<div class="text-center bg1container iproForm">
<div class="headTitle textcenter color1">¿NECESITAS MÁS INFORMACIÓN?</div>
	<?php echo do_shortcode('[contact-form-7 id="41" title="Form portada"]'); ?>
</div>
<!-- FIN MAS INFO -->

<!-- PARTNERS -->
<div class="bg2container iproPartners">
	<div class="partnerTitle texleft">NUESTROS PARTNERS</div>
	<?php
	
		$partners = get_posts(array(
			'showposts' => 4, 
			'post_type' => 'partner',
			'cache_results' => false, // para mejorar rendimiento en dev o prod
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
			'no_found_rows' => true, // para mejorar rendimiento si no existe paginacion
		));
		
		foreach ( $partners as $post ) {   
		?>
		<div class="partner"><?php if(has_post_thumbnail()): ?><a target="_NEW" href="<?= get_post_meta($post->ID, 'wpcf-url-del-partner', true); ?>"><img src="<?= the_post_thumbnail_url(); ?>"></a><?php endif; ?></div>
		<?php
		}
	?>
</div>
<!-- FIN PARTNERS -->

