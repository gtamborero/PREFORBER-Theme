	<!-- FOOTER -->
	<div class="footer bg1container bgcolor1" style="color:#fff;">
		<div class="col-md-4 col-xs-12 responsiveheight">
			<div class="headTitle">CONTACTO</div>
			Grupo ICSA<br />
			Recursos Humanos 2016<br />
			Barcelona - Alicante
		</div>
		<div class="col-md-4 col-xs-12">
			<div class="headTitle">BARCELONA</div>
			<div class="direccion">
			<img src="<?= get_template_directory_uri(); ?>/dist/images/mapabcn.jpg">
			Pau Claris 139, 4º 6ª<br />
			08009 Barcelona<br />
			Tel.: (+34) 932 376 346
			</div>
		</div>
		<div class="col-md-4 col-xs-12">
			<div class="headTitle">ALICANTE</div>
			<div class="direccion">
			<img src="<?= get_template_directory_uri(); ?>/dist/images/mapaalicante.jpg">
			Edificio Baobab, Av. Cataluña 16, 6ª<br />
			03540 Alicante<br />
			Tel.: (+34) 965 230 667
			</div>
		</div>
	</div>
	
	<!-- SUB FOOTER -->
	<div class="footer bg1container bgdarkgrey" >
		<div class="col-md-8 col-xs-12">
			<a href="/aviso-legal">Aviso Legal</a> Copyright ICSA 2016 <a href="/contacto">Contacto</a>
		</div>
		<div class="col-md-4 col-xs-12 redessociales text-right">
			<a href="//www.linkedin.com"><img src="<?= get_template_directory_uri(); ?>/dist/images/linkedin.png"></a>
			<a href="//www.twitter.com"><img src="<?= get_template_directory_uri(); ?>/dist/images/twitter.png"></a>
			<a href="//www.mail.com"><img src="<?= get_template_directory_uri(); ?>/dist/images/mail.png"></a>
		</div>		
	</div>

<script>
// COOKIES JQUERY
// VARIABLES
empresa ="ICSA";
linkPoliticaCookies = "<?php echo get_site_url(); ?>/politica-de-cookies";
colorBoton = "#fff"
fondoBoton = "#4FC7AC";
fondoOverBoton = "#3FB79C";
colorCookies = "#4FC7AC";
colorOverCookies = "#E2F9F3";

// COOKIES PREPARE
jQuery( document ).ready(function() {

    //MOSTRAR UNA SOLA VEZ
    function getCookieData( name ) {
        var pairs = document.cookie.split("; "),
            count = pairs.length, parts;
        while ( count-- ) {
            parts = pairs[count].split("=");
            if ( parts[0] === name )
                return parts[1];
        }
        return false;
    }
	
    var lacookie = getCookieData("lacookie");
    if ( lacookie == '') {

        //General CSS
        jQuery("body").prepend('<div id=cookieAlert></div>');
        jQuery("#cookieAlert").css("background-color", "#000");
        jQuery("#cookieAlert").css("color", "#eee");
        jQuery("#cookieAlert").css("text-align", "center");
        jQuery("#cookieAlert").css("padding", "15px");
		jQuery("#cookieAlert").css("line-height", "24px");

        // TEXTO
        jQuery("#cookieAlert").html("Usamos cookies de terceros para recoger información sobre sus visitas y el uso que hace de nuestra web. En caso de continuar navegando por esta web entenderemos que acepta el uso de estos dispositivos. Más información: <a id=cookies href="+ linkPoliticaCookies +">política de cookies</a>. &nbsp; <a id=acepto>Acepto</a> ");
    
        jQuery("#cookieAlert a").css("cursor", "pointer");

        jQuery("#cookieAlert #acepto").css("padding", "5px 9px");
        jQuery("#cookieAlert #acepto").css("background-color", fondoBoton);
		
        jQuery("#cookieAlert #acepto").mouseenter(function(){
            jQuery("#cookieAlert #acepto").css("background-color", fondoOverBoton);
        }).mouseleave(function(){
            jQuery("#cookieAlert #acepto").css("background-color", fondoBoton);
        });
        jQuery("#cookieAlert #acepto").css("color", colorBoton);
        jQuery("#cookieAlert #acepto").click(function(){
            jQuery("#cookieAlert").hide("fast");
            document.cookie = 'lacookie=1; path=/';
            //console.log(document.cookie);
        });

        // Link politica cookies
        jQuery("#cookieAlert #cookies").css("color", colorCookies);
        jQuery("#cookieAlert #cookies").mouseenter(function(){
        jQuery("#cookieAlert #cookies").css("color", colorOverCookies);
        }).mouseleave(function(){
        jQuery("#cookieAlert #cookies").css("color", colorCookies);
        });
    };
    
    jQuery('.wpcf7-submit').prop('title', 'Recuerde aceptar la política de cookies');
});
// COOKIES FIN

</script>