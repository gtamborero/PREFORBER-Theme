<?php use Roots\Sage\Titles; ?>

<?php /* <div class="page-header">
  <h1><?= Titles\title(); ?></h1>
</div> */?>
