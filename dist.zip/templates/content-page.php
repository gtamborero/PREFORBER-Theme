<div class="medpad minpadtop minpadbottom col-md-12">
	<div class="entry-content textjustify">
	  <?php the_post_thumbnail( 'full', array( 'class' => 'alignright' ) ); ?>
	  <?php the_content(); ?>
	</div>
</div>

<?php wp_link_pages(['before' => '<nav class="page-nav"><p>' . __('Pages:', 'sage'), 'after' => '</p></nav>']); ?>

<?php /* dynamic_sidebar('sidebar-primary'); */ ?>
