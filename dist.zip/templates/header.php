<?php
  // For use with Sagextras (https://github.com/storm2k/sagextras)
?>
<header class="banner navbar navbar-default navbar-static-top" role="banner">
  <div class="container head" >
  
	<div class="containertop">
	  <div class="headmenu">
		  <div class="headbutton2">Teléfono</div>
		  <a href="<?php echo get_site_url(); ?>/su-cuenta"><div class="headbutton minspaceright">Su cuenta</div></a>
		  <a href="<?php echo get_site_url(); ?>/carro"><div class="headbutton">Carrito</div></a>
	  </div>
	  
		<div class="navbar-header">
		  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
			<span class="sr-only"><?= __('Toggle navigation', 'sage'); ?></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		  </button>
		  <a href="<?= esc_url(home_url('/')); ?>"><img id="icsalogo" src="<?= get_template_directory_uri(); 
	?>/dist/images/icsa.png"></a>
		</div>

		<nav class="collapse navbar-collapse navbar-right" role="navigation">

		  <?php
		  if (has_nav_menu('primary_navigation')) :
			wp_nav_menu(['theme_location' => 'primary_navigation', 'menu_class' => 'nav navbar-nav']);
		  endif;
		  ?>
		</nav>
	</div>	
		
		<!-- HEAD SLIDE -->
		<div class="icsabgimg">
			<div class="marco">
				<div class="lead1 h2">
					OFRECEMOS SOLUCIONES GLOBALES 
					PARA LA GESTIÓN Y DIRECCIÓN DE PERSONAS
					<div style="float:right; text-align:right;"><br />... desde 1958</div>
				</div>
				<div class="lead2 headbutton">Solicitar + <br />información</div>
			</div>
		</div>
  </div>
</header>